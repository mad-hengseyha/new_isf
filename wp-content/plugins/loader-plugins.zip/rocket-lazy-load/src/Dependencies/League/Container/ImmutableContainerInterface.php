<?php

namespace RocketLazyLoadPlugin\Dependencies\League\Container;

use RocketLazyLoadPlugin\Dependencies\Interop\Container\ContainerInterface as InteropContainerInterface;

interface ImmutableContainerInterface extends InteropContainerInterface
{

}
