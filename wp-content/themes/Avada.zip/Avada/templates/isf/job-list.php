<?php
$parrams = $args['parrams'];
?>
<div class="col-md-6 col-sm-12 mb-sm-40" data-aos="fade-up">
    <div class="border-top">
        <h3>
            <?php
            echo get_the_title(get_the_ID());
            ?>
        </h3>
        <?php
        $expired_date = get_field('job_expired_date', get_the_ID());
        $commitment = get_field('job_commitment', get_the_ID());
        $position = get_field('job_position', get_the_ID());
        $area = get_field('job_area', get_the_ID());
        echo '<div class="title-and-p-padding">';
        if ($area) {
            echo '<div>';
            echo 'Area: ' . $area;
            echo '</div>';
        }
        if ($position) {
            echo '<div>';
            echo 'Position: ' . $position;
            echo '</div>';
        }
        if ($expired_date) {
            echo 'Apply before: ' . $expired_date;
        }
        if ($commitment) {
            echo '<div>';
            echo 'Commitment: ' . $commitment;
            echo '</div>';
        }
        echo '</div>';
        echo '<div class="">';
        the_excerpt();
        echo '</div>';
        ?>
        <div class="d-flex justify-content-start">
            <div class="m-40 mb-0">
                <a class="isf-link primary-bg-orrange m-auto learn-more-btn" href="<?php echo the_permalink(); ?>">
                    Learn more
                </a>
            </div>
        </div>
    </div>
</div>