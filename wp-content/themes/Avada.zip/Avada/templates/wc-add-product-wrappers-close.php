<?php
/**
 * Product wrappers - close.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       https://theme-fusion.com
 * @package    Avada
 * @subpackage Core
 * @since      5.1.0
 */

?>
		</div>
	</div>
</div>

<?php if ( 'clean' === Avada()->settings->get( 'woocommerce_product_box_design' ) ) : ?>
	</div> <?php // fusion-product-content container. ?>
<?php endif; ?>
