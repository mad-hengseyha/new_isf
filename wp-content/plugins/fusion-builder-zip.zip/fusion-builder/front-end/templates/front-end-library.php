<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<div style="display:none" id="fusion-builder-front-end-library">
	<?php Fusion_Builder_Library()->display_library_content( 'front' ); ?>
</div>
