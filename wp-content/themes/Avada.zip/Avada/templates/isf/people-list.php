<?php
$parrams = $args['parrams'];
?>
<div class="col-md-3 col-sm-12 mb-40" data-aos="fade-up">
    <?php
    echo get_the_post_thumbnail(get_the_ID(), 'full', array('class' => 'img-fluid img-border-radius image-halp'));
    ?>
    <h3 class="">
        <?php
        echo get_the_title(get_the_ID());
        ?>
    </h3>
    <?php
    echo '<h4 class="title-and-p-padding">' . get_field('people_position', get_the_ID()) . ' </h4>';

    // the_excerpt();
    ?>
    <div class="more mb-20 people-max-height post_id_<?php echo get_the_ID(); ?>">
        <?php the_content(); ?>
        <?php
        if (get_field('people_linkedin_url', get_the_ID())) {
        ?>
            <div class="col-12 d-flex linkedin-profile">
                <div class="linkedin-icon">
                    <img src="<?php echo get_field('people_linkedin_icon', get_the_ID()); ?> " />
                </div>
                <div class="linkedin-name">
                    <a target="_blank" class="" href="<?php echo get_field('people_linkedin_url', get_the_ID()); ?>"> <?php echo get_field('people_linkedin_name', get_the_ID()); ?></a>
                </div>
            </div>
        <?php
        }
        ?>
    </div>
    <div class="d-flex justify-content-start">
        <div class="isf-link-wraper">
            <a class="isf-link" data-class="post_id_<?php echo get_the_ID(); ?>" href="<?php //echo the_permalink(); 
                                                                                        ?>">
                <div class="slide-in-bottom">
                    <div class="learn_more" data-hover="Learn more">
                        Learn more
                    </div>
                    <div class=" custom-styles w-embed"></div>
                </div>
            </a>
        </div>
    </div>

</div>