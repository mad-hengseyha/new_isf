<?php
/**
 * An underscore.js template.
 *
 * @package fusion-builder
 */

?>
<script type="text/template" id="fusion-layouts-template">
	<div class="fusion-layouts-grid">
	</div>
</script>
