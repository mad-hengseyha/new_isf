<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_tb_author-shortcode">
	{{{styles}}}
	<section {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{output}}}
	</section>
</script>
