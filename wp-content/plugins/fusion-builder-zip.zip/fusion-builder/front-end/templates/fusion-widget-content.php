<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 6.0
 */

?>
<script type="text/html" id="tmpl-fusion_widget_content">
	<# if ( 'undefined' !== typeof markup ) { #>
		{{{ markup }}}
	<# } #>
</script>
