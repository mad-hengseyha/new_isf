<?php
/**
 * Product main wrapper - open.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       https://theme-fusion.com
 * @package    Avada
 * @subpackage Core
 * @since      7.2
 */

?>
<div class="fusion-product-wrapper">
